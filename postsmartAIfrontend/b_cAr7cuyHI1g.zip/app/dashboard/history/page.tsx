"use client"

import { useState, useMemo } from "react"
import {
  Search,
  Filter,
  Calendar,
  Eye,
  Copy,
  Trash2,
  ChevronLeft,
  ChevronRight,
  X,
} from "lucide-react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Skeleton } from "@/components/ui/skeleton"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"
import { useHistoryEmails, useDeleteEmail, type HistoryEmail } from "@/hooks/use-api"

const typeColors: Record<string, string> = {
  Livraison: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  Réclamation: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
  Information: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  Confirmation: "bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400",
  Relance: "bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400",
}

function HistorySkeleton() {
  return (
    <div className="space-y-3">
      {[1, 2, 3, 4, 5].map((i) => (
        <div
          key={i}
          className="flex items-center justify-between p-4 rounded-lg border border-border"
        >
          <div className="flex-1 space-y-2">
            <div className="flex items-center gap-3">
              <Skeleton className="h-5 w-64" />
              <Skeleton className="h-5 w-20 rounded-full" />
            </div>
            <Skeleton className="h-4 w-48" />
          </div>
          <div className="flex items-center gap-2">
            <Skeleton className="h-8 w-8 rounded" />
            <Skeleton className="h-8 w-8 rounded" />
            <Skeleton className="h-8 w-8 rounded" />
          </div>
        </div>
      ))}
    </div>
  )
}

export default function HistoryPage() {
  const [search, setSearch] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [selectedEmail, setSelectedEmail] = useState<HistoryEmail | null>(null)
  const [currentPage, setCurrentPage] = useState(1)
  const itemsPerPage = 5

  const { data: historyData, isLoading } = useHistoryEmails()
  const deleteMutation = useDeleteEmail()

  const filteredData = useMemo(() => {
    if (!historyData) return []
    return historyData.filter((item) => {
      const matchesSearch =
        item.subject.toLowerCase().includes(search.toLowerCase()) ||
        item.client.toLowerCase().includes(search.toLowerCase())
      const matchesType = typeFilter === "all" || item.type === typeFilter
      return matchesSearch && matchesType
    })
  }, [historyData, search, typeFilter])

  const totalPages = Math.ceil(filteredData.length / itemsPerPage)
  const paginatedData = filteredData.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  )

  const handleCopy = (content: string) => {
    navigator.clipboard.writeText(content)
  }

  const handleDelete = (emailId: number) => {
    deleteMutation.mutate(emailId)
  }

  return (
    <div className="p-6 lg:p-8 space-y-6">
      {/* Header */}
      <div className="space-y-1">
        <h1 className="text-2xl lg:text-3xl font-bold text-foreground">
          Historique
        </h1>
        <p className="text-muted-foreground">
          Retrouvez tous les emails que vous avez générés.
        </p>
      </div>

      {/* Filters */}
      <Card className="border-border/50">
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Rechercher par sujet ou client..."
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value)
                  setCurrentPage(1)
                }}
                className="pl-10"
              />
            </div>
            <div className="flex gap-3">
              <Select
                value={typeFilter}
                onValueChange={(value) => {
                  setTypeFilter(value)
                  setCurrentPage(1)
                }}
              >
                <SelectTrigger className="w-[180px]">
                  <Filter className="h-4 w-4 mr-2 text-muted-foreground" />
                  <SelectValue placeholder="Type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Tous les types</SelectItem>
                  <SelectItem value="Livraison">Livraison</SelectItem>
                  <SelectItem value="Réclamation">Réclamation</SelectItem>
                  <SelectItem value="Information">Information</SelectItem>
                  <SelectItem value="Confirmation">Confirmation</SelectItem>
                  <SelectItem value="Relance">Relance</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* History List */}
      <Card className="border-border/50">
        <CardHeader>
          <CardTitle className="text-foreground">Emails générés</CardTitle>
          <CardDescription>
            {isLoading
              ? "Chargement..."
              : `${filteredData.length} email${filteredData.length > 1 ? "s" : ""} trouvé${filteredData.length > 1 ? "s" : ""}`}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <HistorySkeleton />
          ) : (
            <>
              <div className="space-y-3">
                {paginatedData.map((item) => (
                  <div
                    key={item.id}
                    className="flex items-center justify-between p-4 rounded-lg border border-border bg-card hover:bg-muted/50 transition-colors"
                  >
                    <div className="flex-1 min-w-0 space-y-1">
                      <div className="flex items-center gap-3">
                        <h3 className="font-medium text-foreground truncate">
                          {item.subject}
                        </h3>
                        <Badge variant="secondary" className={cn("shrink-0", typeColors[item.type])}>
                          {item.type}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-3 text-sm text-muted-foreground">
                        <span>{item.client}</span>
                        <span>•</span>
                        <span className="flex items-center gap-1">
                          <Calendar className="h-3 w-3" />
                          {item.date} à {item.time}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 ml-4">
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => setSelectedEmail(item)}
                      >
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8"
                        onClick={() => handleCopy(item.content)}
                      >
                        <Copy className="h-4 w-4" />
                      </Button>
                      <Button
                        variant="ghost"
                        size="icon"
                        className="h-8 w-8 text-destructive hover:text-destructive"
                        onClick={() => handleDelete(item.id)}
                        disabled={deleteMutation.isPending}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                ))}

                {filteredData.length === 0 && (
                  <div className="text-center py-12">
                    <p className="text-muted-foreground">
                      Aucun email trouvé correspondant à vos critères.
                    </p>
                  </div>
                )}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center justify-between mt-6 pt-4 border-t border-border">
                  <p className="text-sm text-muted-foreground">
                    Page {currentPage} sur {totalPages}
                  </p>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                      disabled={currentPage === 1}
                    >
                      <ChevronLeft className="h-4 w-4" />
                    </Button>
                    <Button
                      variant="outline"
                      size="icon"
                      className="h-8 w-8"
                      onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                      disabled={currentPage === totalPages}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              )}
            </>
          )}
        </CardContent>
      </Card>

      {/* Email Preview Dialog */}
      <Dialog open={!!selectedEmail} onOpenChange={() => setSelectedEmail(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <div className="flex items-start justify-between gap-4">
              <div className="space-y-1">
                <DialogTitle className="text-foreground">{selectedEmail?.subject}</DialogTitle>
                <DialogDescription>
                  {selectedEmail?.client} • {selectedEmail?.date} à {selectedEmail?.time}
                </DialogDescription>
              </div>
              {selectedEmail && (
                <Badge variant="secondary" className={cn("shrink-0 mt-1", typeColors[selectedEmail.type])}>
                  {selectedEmail.type}
                </Badge>
              )}
            </div>
          </DialogHeader>
          <div className="mt-4 p-4 rounded-lg bg-muted/50 border border-border">
            <pre className="whitespace-pre-wrap text-sm text-foreground font-sans leading-relaxed">
              {selectedEmail?.content}
            </pre>
          </div>
          <div className="flex justify-end gap-3 mt-4">
            <Button variant="outline" onClick={() => setSelectedEmail(null)}>
              <X className="h-4 w-4 mr-2" />
              Fermer
            </Button>
            <Button onClick={() => selectedEmail && handleCopy(selectedEmail.content)}>
              <Copy className="h-4 w-4 mr-2" />
              Copier
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  )
}
