"use client"

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"

// Types
export interface DashboardStats {
  emailsGenerated: number
  emailsTrend: string
  avgTime: string
  timeTrend: string
  satisfaction: number
  satisfactionTrend: string
  documentsIndexed: number
  documentsTrend: string
}

export interface RecentEmail {
  id: number
  subject: string
  client: string
  date: string
  type: string
}

export interface HistoryEmail {
  id: number
  subject: string
  client: string
  type: string
  date: string
  time: string
  content: string
}

export interface KnowledgeDocument {
  id: number
  title: string
  category: string
  type: string
  lastUpdated: string
  size: string
}

export interface GenerateEmailParams {
  clientName: string
  emailType: string
  tone: string
  context: string
  additionalInfo?: string
}

// Mock API functions (would connect to real backend)
const fetchDashboardStats = async (): Promise<DashboardStats> => {
  await new Promise((resolve) => setTimeout(resolve, 500))
  return {
    emailsGenerated: 147,
    emailsTrend: "+12%",
    avgTime: "45s",
    timeTrend: "-23%",
    satisfaction: 94,
    satisfactionTrend: "+5%",
    documentsIndexed: 23,
    documentsTrend: "+3",
  }
}

const fetchRecentEmails = async (): Promise<RecentEmail[]> => {
  await new Promise((resolve) => setTimeout(resolve, 300))
  return [
    {
      id: 1,
      subject: "Confirmation de livraison",
      client: "Marie Martin",
      date: "Il y a 2 heures",
      type: "Livraison",
    },
    {
      id: 2,
      subject: "Suivi de réclamation",
      client: "Pierre Bernard",
      date: "Il y a 4 heures",
      type: "Réclamation",
    },
    {
      id: 3,
      subject: "Information tarifs",
      client: "Sophie Leroy",
      date: "Hier",
      type: "Information",
    },
  ]
}

const fetchHistoryEmails = async (): Promise<HistoryEmail[]> => {
  await new Promise((resolve) => setTimeout(resolve, 400))
  return [
    {
      id: 1,
      subject: "Confirmation de livraison - Colis LP123456789FR",
      client: "Marie Martin",
      type: "Livraison",
      date: "17 avril 2026",
      time: "14:32",
      content: `Madame Martin,

Suite à votre demande concernant le suivi de votre colis n°LP123456789FR, je me permets de vous apporter les informations suivantes.

Votre colis a bien été pris en charge par nos services le 15 janvier 2026. Après vérification auprès de notre service logistique, je peux vous confirmer que votre envoi est actuellement en transit et devrait être livré à l'adresse indiquée dans les 48 heures ouvrées.

Cordialement,
Jean Dupont`,
    },
    {
      id: 2,
      subject: "Réponse à réclamation - Colis endommagé",
      client: "Pierre Bernard",
      type: "Réclamation",
      date: "17 avril 2026",
      time: "11:15",
      content: `Monsieur Bernard,

Je fais suite à votre réclamation concernant les dommages constatés sur votre colis. Je comprends parfaitement votre mécontentement et vous présente nos sincères excuses pour ce désagrément.

Après examen de votre dossier, nous avons ouvert une procédure d'indemnisation. Un conseiller vous contactera sous 48h pour finaliser votre dossier.

Cordialement,
Jean Dupont`,
    },
    {
      id: 3,
      subject: "Information tarifs - Envoi international",
      client: "Sophie Leroy",
      type: "Information",
      date: "16 avril 2026",
      time: "16:45",
      content: `Madame Leroy,

Suite à votre demande d'information concernant les tarifs d'envoi vers le Canada, voici les options disponibles :

- Colissimo International : 25,50€ (délai 7-10 jours)
- Chronopost International : 65,00€ (délai 2-4 jours)

N'hésitez pas à me contacter pour toute information complémentaire.

Cordialement,
Jean Dupont`,
    },
    {
      id: 4,
      subject: "Confirmation de service - Réexpédition",
      client: "Thomas Petit",
      type: "Confirmation",
      date: "16 avril 2026",
      time: "09:20",
      content: `Monsieur Petit,

Je vous confirme la mise en place de votre service de réexpédition définitive à compter du 1er mai 2026.

Tous vos courriers seront désormais acheminés à votre nouvelle adresse.

Cordialement,
Jean Dupont`,
    },
    {
      id: 5,
      subject: "Relance - Documents manquants",
      client: "Emma Dubois",
      type: "Relance",
      date: "15 avril 2026",
      time: "14:00",
      content: `Madame Dubois,

Je me permets de vous relancer concernant les documents nécessaires à l'ouverture de votre compte professionnel La Poste.

Les pièces suivantes sont toujours en attente :
- Extrait Kbis de moins de 3 mois
- Pièce d'identité du gérant

Cordialement,
Jean Dupont`,
    },
    {
      id: 6,
      subject: "Suivi de livraison - Express",
      client: "Lucas Moreau",
      type: "Livraison",
      date: "15 avril 2026",
      time: "10:30",
      content: `Monsieur Moreau,

Votre envoi Chronopost n°CH987654321FR a été livré ce jour à 09h45.

La signature a été recueillie par M. Moreau.

Cordialement,
Jean Dupont`,
    },
  ]
}

const fetchKnowledgeDocuments = async (): Promise<KnowledgeDocument[]> => {
  await new Promise((resolve) => setTimeout(resolve, 350))
  return [
    {
      id: 1,
      title: "Procédure réclamation colis",
      category: "Procédures",
      type: "PDF",
      lastUpdated: "15 avril 2026",
      size: "2.4 MB",
    },
    {
      id: 2,
      title: "Grille tarifaire 2026",
      category: "Tarifs",
      type: "XLSX",
      lastUpdated: "1 avril 2026",
      size: "1.8 MB",
    },
    {
      id: 3,
      title: "Modèle réponse retard livraison",
      category: "Modèles",
      type: "DOCX",
      lastUpdated: "10 avril 2026",
      size: "156 KB",
    },
    {
      id: 4,
      title: "Règlement service Chronopost",
      category: "Règlements",
      type: "PDF",
      lastUpdated: "1 mars 2026",
      size: "4.2 MB",
    },
    {
      id: 5,
      title: "Procédure indemnisation",
      category: "Procédures",
      type: "PDF",
      lastUpdated: "12 avril 2026",
      size: "1.1 MB",
    },
    {
      id: 6,
      title: "FAQ Service Client",
      category: "Procédures",
      type: "PDF",
      lastUpdated: "8 avril 2026",
      size: "890 KB",
    },
  ]
}

const generateEmail = async (params: GenerateEmailParams): Promise<string> => {
  await new Promise((resolve) => setTimeout(resolve, 2000))
  
  const greeting = params.tone === "formel" ? "Madame, Monsieur" : 
    params.clientName ? `${params.clientName.includes("Mme") || params.clientName.includes("Madame") ? "Madame" : "Monsieur"} ${params.clientName.split(" ").pop()}` : "Madame, Monsieur"
  
  return `${greeting},

Suite à votre demande, je me permets de vous apporter les informations suivantes.

${params.context}

${params.additionalInfo ? `\nInformations complémentaires :\n${params.additionalInfo}\n` : ""}
Je reste à votre entière disposition pour tout renseignement complémentaire.

Cordialement,

Jean Dupont
Conseiller clientèle
La Poste - Service Client`
}

// React Query Hooks
export function useDashboardStats() {
  return useQuery({
    queryKey: ["dashboard", "stats"],
    queryFn: fetchDashboardStats,
  })
}

export function useRecentEmails() {
  return useQuery({
    queryKey: ["dashboard", "recentEmails"],
    queryFn: fetchRecentEmails,
  })
}

export function useHistoryEmails() {
  return useQuery({
    queryKey: ["history", "emails"],
    queryFn: fetchHistoryEmails,
  })
}

export function useKnowledgeDocuments() {
  return useQuery({
    queryKey: ["knowledge", "documents"],
    queryFn: fetchKnowledgeDocuments,
  })
}

export function useGenerateEmail() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: generateEmail,
    onSuccess: () => {
      // Invalidate and refetch related queries
      queryClient.invalidateQueries({ queryKey: ["dashboard"] })
      queryClient.invalidateQueries({ queryKey: ["history"] })
    },
  })
}

export function useDeleteEmail() {
  const queryClient = useQueryClient()
  
  return useMutation({
    mutationFn: async (emailId: number) => {
      await new Promise((resolve) => setTimeout(resolve, 300))
      return emailId
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["history"] })
      queryClient.invalidateQueries({ queryKey: ["dashboard", "recentEmails"] })
    },
  })
}
